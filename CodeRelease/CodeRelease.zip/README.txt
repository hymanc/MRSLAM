Most revised code is in the /Clean Folder. The primary simulations are
/clean/Simulate_Howard.m                   (Basic Howard MRSLAM Algorithm)
/clean/Simulate_Howard_MultiPF.m	   (Howard MRSLAM w/ independent pose resampling)
/clean/Simulate_Howard_MultiPF_MultiMap.m  (Howard MRSLAM w/ multiple maps and ind. pose resampling)


Earlier prototypes are in the /Code folder

Code was written for use in MATLAB R2014. Some features, particularly parallel execution, may not
work in R2015 or later due to changes/deprecation in the Parallel Computing Toolbox.