function nr = rows(A)

nr = size(A,1);

end
